// dit is een opmerking
// regel afsluiten met een ;

console.log("Hello Winc Academy");

// EOF
