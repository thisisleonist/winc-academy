const age = 42;
const isFemale = false;
const driverStatus = 'bob';

if(age >= 18){
    console.log('You may enter!');
} else {
    console.log('You may NOT enter!');
}

if(isFemale === true){
    console.log('You are a female');
} else {
    console.log('You are NOT a female!');
}

if(driverStatus === 'bob'){
    console.log('Jammer joh, jij bent de ‘bob’!');
} else {
    console.log('Neem er nog een!');
}